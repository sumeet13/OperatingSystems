//
//  main.c
//  Hello_World
//
//  Created by Sumeet Maan on 9/1/20.
//  Copyright © 2020 Sumeet Maan. All rights reserved.
//

#include <stdio.h>

int main(void) {
    // insert code here...
    printf("Hello World!...\n");
    return 0;
}
